import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import DivaHologramGhost from '../components/DivaHologramGhost';

// Mock @react-three/fiber
vi.mock('@react-three/fiber', () => ({
  Canvas: ({ children }) => <div data-testid="canvas">{children}</div>,
  useFrame: vi.fn((callback) => {
    // Simulate frame callback for testing
    const mockState = {
      clock: { elapsedTime: 1 },
    };
    callback(mockState);
  }),
  useLoader: vi.fn((loader, url) => {
    if (url) {
      return {
        scene: {
          clone: () => ({ type: 'Object3D', position: { x: 0, y: 0, z: 0 } }),
        },
      };
    }
    return null;
  }),
}));

// Mock @react-three/drei
vi.mock('@react-three/drei', () => ({
  OrbitControls: () => <div data-testid="orbit-controls" />,
}));

// Mock GLTFLoader
vi.mock('three/examples/jsm/loaders/GLTFLoader', () => ({
  GLTFLoader: vi.fn(),
}));

// Mock Three.js
vi.mock('three', () => ({
  Points: class MockPoints {},
  Group: class MockGroup {},
  Mesh: class MockMesh {},
  BufferGeometry: class MockBufferGeometry {},
  PointsMaterial: class MockPointsMaterial {},
  BoxGeometry: class MockBoxGeometry {},
  MeshStandardMaterial: class MockMeshStandardMaterial {},
}));

describe('DivaHologramGhost Component', () => {
  let mockSpeechRecognition;
  let user;

  beforeEach(() => {
    // Reset all mocks
    vi.clearAllMocks();
    
    // Setup user event
    user = userEvent.setup();

    // Mock Speech Recognition
    mockSpeechRecognition = {
      continuous: false,
      interimResults: false,
      lang: 'en-US',
      onresult: null,
      onerror: null,
      onstart: null,
      onend: null,
      start: vi.fn(),
      stop: vi.fn(),
      abort: vi.fn(),
    };

    global.SpeechRecognition = vi.fn(() => mockSpeechRecognition);
    global.webkitSpeechRecognition = global.SpeechRecognition;

    // Mock URL methods
    global.URL.createObjectURL = vi.fn().mockReturnValue('blob:mock-url');
    global.URL.revokeObjectURL = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Component Rendering', () => {
    it('renders the main title and description', () => {
      render(<DivaHologramGhost />);
      
      expect(screen.getByText('Diva Hologram Ghost')).toBeInTheDocument();
      expect(screen.getByText('3D Model Viewer with Ghost Animations & Voice Controls')).toBeInTheDocument();
    });

    it('renders all control panels', () => {
      render(<DivaHologramGhost />);
      
      expect(screen.getByText('Animation')).toBeInTheDocument();
      expect(screen.getByText('Ghost Mode')).toBeInTheDocument();
      expect(screen.getByText('Model Upload')).toBeInTheDocument();
      expect(screen.getByText('Voice Control')).toBeInTheDocument();
    });

    it('renders four hologram viewports', () => {
      render(<DivaHologramGhost />);
      
      for (let i = 1; i <= 4; i++) {
        expect(screen.getByTestId(`viewport-${i}`)).toBeInTheDocument();
        expect(screen.getByText(`Viewport ${i}`)).toBeInTheDocument();
      }
    });

    it('renders all canvas elements', () => {
      render(<DivaHologramGhost />);
      
      const canvasElements = screen.getAllByTestId('canvas');
      expect(canvasElements).toHaveLength(4);
    });
  });

  describe('Animation Controls', () => {
    it('displays initial play button state', () => {
      render(<DivaHologramGhost />);
      
      const playButton = screen.getByTestId('play-pause-button');
      expect(playButton).toHaveTextContent('Play');
    });

    it('toggles play/pause state when button is clicked', async () => {
      render(<DivaHologramGhost />);
      
      const playButton = screen.getByTestId('play-pause-button');
      
      // Initially should show "Play"
      expect(playButton).toHaveTextContent('Play');
      
      // Click to start playing
      await user.click(playButton);
      expect(playButton).toHaveTextContent('Pause');
      
      // Click to pause
      await user.click(playButton);
      expect(playButton).toHaveTextContent('Play');
    });

    it('changes animation type when dropdown selection changes', async () => {
      render(<DivaHologramGhost />);
      
      const animationSelect = screen.getByTestId('animation-select');
      
      // Initially should be "float"
      expect(animationSelect.value).toBe('float');
      
      // Change to "rotate"
      await user.selectOptions(animationSelect, 'rotate');
      expect(animationSelect.value).toBe('rotate');
      
      // Change to "pulse"
      await user.selectOptions(animationSelect, 'pulse');
      expect(animationSelect.value).toBe('pulse');
      
      // Change to "fade"
      await user.selectOptions(animationSelect, 'fade');
      expect(animationSelect.value).toBe('fade');
    });

    it('updates speed when slider value changes', async () => {
      render(<DivaHologramGhost />);
      
      const speedSlider = screen.getByTestId('speed-slider');
      const speedLabel = screen.getByText(/Speed: 1\.0x/);
      
      // Initially should be 1.0
      expect(speedSlider.value).toBe('1');
      expect(speedLabel).toBeInTheDocument();
      
      // Change speed to 2.0
      fireEvent.change(speedSlider, { target: { value: '2.0' } });
      expect(speedSlider.value).toBe('2.0');
      expect(screen.getByText(/Speed: 2\.0x/)).toBeInTheDocument();
    });
  });

  describe('Ghost Mode Controls', () => {
    it('displays initial ghost mode state', () => {
      render(<DivaHologramGhost />);
      
      const ghostButton = screen.getByTestId('ghost-mode-button');
      expect(ghostButton).toHaveTextContent('Normal Mode');
    });

    it('toggles ghost mode when button is clicked', async () => {
      render(<DivaHologramGhost />);
      
      const ghostButton = screen.getByTestId('ghost-mode-button');
      
      // Initially should show "Normal Mode"
      expect(ghostButton).toHaveTextContent('Normal Mode');
      
      // Click to enable ghost mode
      await user.click(ghostButton);
      expect(ghostButton).toHaveTextContent('Ghost Active');
      
      // Click to disable ghost mode
      await user.click(ghostButton);
      expect(ghostButton).toHaveTextContent('Normal Mode');
    });

    it('toggles particle effects when particles button is clicked', async () => {
      render(<DivaHologramGhost />);
      
      const particlesButton = screen.getByTestId('particles-button');
      
      // Initially should show "Particles On"
      expect(particlesButton).toHaveTextContent('Particles On');
      
      // Click to disable particles
      await user.click(particlesButton);
      expect(particlesButton).toHaveTextContent('Particles Off');
      
      // Click to enable particles
      await user.click(particlesButton);
      expect(particlesButton).toHaveTextContent('Particles On');
    });
  });

  describe('File Upload Controls', () => {
    it('renders file upload area', () => {
      render(<DivaHologramGhost />);
      
      expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
      expect(screen.getByTestId('file-select-button')).toBeInTheDocument();
      expect(screen.getByText('Drop .GLB file here or')).toBeInTheDocument();
    });

    it('handles file selection through file input', async () => {
      render(<DivaHologramGhost />);
      
      const fileInput = screen.getByTestId('file-input');
      const file = new File(['test content'], 'test-model.glb', { type: 'model/gltf-binary' });
      
      await user.upload(fileInput, file);
      
      expect(screen.getByTestId('selected-file')).toHaveTextContent('Selected: test-model.glb');
    });

    it('handles file selection through button click', async () => {
      render(<DivaHologramGhost />);
      
      const fileSelectButton = screen.getByTestId('file-select-button');
      const fileInput = screen.getByTestId('file-input');
      
      // Mock the file input click
      const clickSpy = vi.spyOn(fileInput, 'click');
      await user.click(fileSelectButton);
      
      expect(clickSpy).toHaveBeenCalled();
    });

    it('handles drag and drop file selection', async () => {
      render(<DivaHologramGhost />);
      
      const dropZone = screen.getByTestId('drop-zone');
      const file = new File(['test content'], 'test-model.glb', { type: 'model/gltf-binary' });
      
      const dropEvent = {
        preventDefault: vi.fn(),
        dataTransfer: {
          files: [file]
        }
      };
      
      fireEvent.drop(dropZone, dropEvent);
      
      expect(screen.getByTestId('selected-file')).toHaveTextContent('Selected: test-model.glb');
    });

    it('only accepts .glb files', async () => {
      render(<DivaHologramGhost />);
      
      const fileInput = screen.getByTestId('file-input');
      const invalidFile = new File(['test content'], 'test-model.obj', { type: 'text/plain' });
      
      await user.upload(fileInput, invalidFile);
      
      // Should not show selected file for non-GLB files
      expect(screen.queryByTestId('selected-file')).not.toBeInTheDocument();
    });
  });

  describe('Voice Control', () => {
    it('displays initial voice control state', () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      const statusText = screen.getByTestId('voice-status');
      
      expect(voiceButton).toHaveTextContent('Start Listening');
      expect(statusText).toHaveTextContent('Not listening');
    });

    it('toggles voice recognition when button is clicked', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      
      // Click to start listening
      await user.click(voiceButton);
      
      expect(mockSpeechRecognition.start).toHaveBeenCalled();
      expect(voiceButton).toHaveTextContent('Stop Listening');
      expect(screen.getByTestId('voice-status')).toHaveTextContent('Listening...');
    });

    it('processes voice commands correctly', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      // Simulate voice command result
      const playCommand = {
        results: [
          [{ transcript: 'play animation' }]
        ]
      };
      
      // Trigger the onresult callback
      mockSpeechRecognition.onresult(playCommand);
      
      await waitFor(() => {
        expect(screen.getByTestId('last-command')).toHaveTextContent('"play animation"');
        expect(screen.getByTestId('play-pause-button')).toHaveTextContent('Pause');
      });
    });

    it('processes ghost mode voice command', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      const ghostCommand = {
        results: [
          [{ transcript: 'enable ghost mode' }]
        ]
      };
      
      mockSpeechRecognition.onresult(ghostCommand);
      
      await waitFor(() => {
        expect(screen.getByTestId('ghost-mode-button')).toHaveTextContent('Ghost Active');
      });
    });

    it('processes animation type voice commands', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      const rotateCommand = {
        results: [
          [{ transcript: 'rotate animation' }]
        ]
      };
      
      mockSpeechRecognition.onresult(rotateCommand);
      
      await waitFor(() => {
        expect(screen.getByTestId('animation-select').value).toBe('rotate');
      });
    });

    it('processes speed control voice commands', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      const fasterCommand = {
        results: [
          [{ transcript: 'make it faster' }]
        ]
      };
      
      mockSpeechRecognition.onresult(fasterCommand);
      
      await waitFor(() => {
        expect(screen.getByTestId('speed-slider').value).toBe('1.5');
      });
    });
  });

  describe('Reset Functionality', () => {
    it('resets all controls to default state', async () => {
      render(<DivaHologramGhost />);
      
      // Change some settings first
      const playButton = screen.getByTestId('play-pause-button');
      const ghostButton = screen.getByTestId('ghost-mode-button');
      const animationSelect = screen.getByTestId('animation-select');
      const speedSlider = screen.getByTestId('speed-slider');
      
      await user.click(playButton); // Start playing
      await user.click(ghostButton); // Enable ghost mode
      await user.selectOptions(animationSelect, 'rotate'); // Change animation
      fireEvent.change(speedSlider, { target: { value: '2.0' } }); // Change speed
      
      // Verify changes were applied
      expect(playButton).toHaveTextContent('Pause');
      expect(ghostButton).toHaveTextContent('Ghost Active');
      expect(animationSelect.value).toBe('rotate');
      expect(speedSlider.value).toBe('2.0');
      
      // Reset
      const resetButton = screen.getByTestId('reset-button');
      await user.click(resetButton);
      
      // Verify reset
      expect(playButton).toHaveTextContent('Play');
      expect(ghostButton).toHaveTextContent('Normal Mode');
      expect(animationSelect.value).toBe('float');
      expect(speedSlider.value).toBe('1');
    });

    it('clears selected file and last command on reset', async () => {
      render(<DivaHologramGhost />);
      
      // Add a file
      const fileInput = screen.getByTestId('file-input');
      const file = new File(['test'], 'test.glb', { type: 'model/gltf-binary' });
      await user.upload(fileInput, file);
      
      expect(screen.getByTestId('selected-file')).toBeInTheDocument();
      
      // Reset
      const resetButton = screen.getByTestId('reset-button');
      await user.click(resetButton);
      
      // Verify file is cleared
      expect(screen.queryByTestId('selected-file')).not.toBeInTheDocument();
    });
  });

  describe('Status Indicators', () => {
    it('displays correct animation status based on play state', async () => {
      render(<DivaHologramGhost />);
      
      const playButton = screen.getByTestId('play-pause-button');
      
      // Initially paused
      expect(playButton).toHaveTextContent('Play');
      
      // Start playing
      await user.click(playButton);
      expect(playButton).toHaveTextContent('Pause');
    });

    it('displays correct voice recognition status', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      const statusText = screen.getByTestId('voice-status');
      
      // Initially not listening
      expect(statusText).toHaveTextContent('Not listening');
      
      // Start listening
      await user.click(voiceButton);
      expect(statusText).toHaveTextContent('Listening...');
    });

    it('shows last voice command when processed', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      const command = {
        results: [
          [{ transcript: 'test command' }]
        ]
      };
      
      mockSpeechRecognition.onresult(command);
      
      await waitFor(() => {
        expect(screen.getByTestId('last-command')).toHaveTextContent('"test command"');
      });
    });
  });

  describe('Error Handling', () => {
    it('handles speech recognition errors gracefully', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      // Simulate error
      mockSpeechRecognition.onerror();
      
      await waitFor(() => {
        expect(screen.getByTestId('voice-status')).toHaveTextContent('Not listening');
      });
    });

    it('handles speech recognition end event', async () => {
      render(<DivaHologramGhost />);
      
      const voiceButton = screen.getByTestId('voice-button');
      await user.click(voiceButton);
      
      // Simulate end event
      mockSpeechRecognition.onend();
      
      await waitFor(() => {
        expect(screen.getByTestId('voice-status')).toHaveTextContent('Not listening');
      });
    });

    it('handles unsupported speech recognition gracefully', () => {
      // Remove speech recognition support
      delete global.SpeechRecognition;
      delete global.webkitSpeechRecognition;
      
      expect(() => render(<DivaHologramGhost />)).not.toThrow();
    });
  });
});