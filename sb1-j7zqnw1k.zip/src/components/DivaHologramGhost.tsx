import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Canvas, useFrame, useLoader } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Upload, 
  Mic, 
  Ghost, 
  Sparkles,
  Settings
} from 'lucide-react';
import * as THREE from 'three';

// Particle System Component
function ParticleSystem({ count = 100 }) {
  const mesh = useRef<THREE.Points>(null);
  const positions = new Float32Array(count * 3);
  
  for (let i = 0; i < count * 3; i++) {
    positions[i] = (Math.random() - 0.5) * 10;
  }

  useFrame((state) => {
    if (mesh.current) {
      mesh.current.rotation.y += 0.002;
      const positions = mesh.current.geometry.attributes.position.array as Float32Array;
      for (let i = 1; i < positions.length; i += 3) {
        positions[i] += Math.sin(state.clock.elapsedTime + i) * 0.01;
      }
      mesh.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial color="#64ffda" size={0.02} transparent opacity={0.6} />
    </points>
  );
}

// Hologram Model Component
function HologramModel({ 
  modelUrl, 
  animationType, 
  speed, 
  ghostMode 
}: {
  modelUrl?: string;
  animationType: string;
  speed: number;
  ghostMode: boolean;
}) {
  const meshRef = useRef<THREE.Group>(null);
  const gltf = modelUrl ? useLoader(GLTFLoader, modelUrl) : null;

  useFrame((state) => {
    if (!meshRef.current) return;

    const elapsed = state.clock.elapsedTime * speed;

    switch (animationType) {
      case 'float':
        meshRef.current.position.y = Math.sin(elapsed) * 0.5;
        break;
      case 'rotate':
        meshRef.current.rotation.y = elapsed;
        break;
      case 'pulse':
        const scale = 1 + Math.sin(elapsed * 2) * 0.2;
        meshRef.current.scale.setScalar(scale);
        break;
      case 'fade':
        const opacity = 0.5 + Math.sin(elapsed) * 0.3;
        meshRef.current.traverse((child) => {
          if (child instanceof THREE.Mesh && child.material) {
            if (Array.isArray(child.material)) {
              child.material.forEach(mat => {
                if ('opacity' in mat) mat.opacity = opacity;
              });
            } else if ('opacity' in child.material) {
              child.material.opacity = opacity;
            }
          }
        });
        break;
    }
  });

  if (!gltf) {
    return (
      <mesh ref={meshRef}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial 
          color={ghostMode ? "#9333ea" : "#3b82f6"} 
          transparent 
          opacity={ghostMode ? 0.5 : 0.8}
          wireframe={ghostMode}
        />
      </mesh>
    );
  }

  return <primitive ref={meshRef} object={gltf.scene.clone()} />;
}

// Main Component
export default function DivaHologramGhost() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [animationType, setAnimationType] = useState('float');
  const [speed, setSpeed] = useState(1);
  const [ghostMode, setGhostMode] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [modelUrl, setModelUrl] = useState<string>('');
  const [isListening, setIsListening] = useState(false);
  const [lastCommand, setLastCommand] = useState('');
  const [particlesEnabled, setParticlesEnabled] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Voice Commands Setup
  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      if (recognitionRef.current) {
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event) => {
          const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase();
          setLastCommand(transcript);
          processVoiceCommand(transcript);
        };

        recognitionRef.current.onerror = () => {
          setIsListening(false);
        };

        recognitionRef.current.onend = () => {
          setIsListening(false);
        };
      }
    }
  }, []);

  const processVoiceCommand = useCallback((command: string) => {
    if (command.includes('play') || command.includes('start')) {
      setIsPlaying(true);
    } else if (command.includes('pause') || command.includes('stop')) {
      setIsPlaying(false);
    } else if (command.includes('ghost')) {
      setGhostMode(true);
    } else if (command.includes('normal')) {
      setGhostMode(false);
    } else if (command.includes('float')) {
      setAnimationType('float');
    } else if (command.includes('rotate')) {
      setAnimationType('rotate');
    } else if (command.includes('pulse')) {
      setAnimationType('pulse');
    } else if (command.includes('fade')) {
      setAnimationType('fade');
    } else if (command.includes('faster')) {
      setSpeed(prev => Math.min(prev + 0.5, 3));
    } else if (command.includes('slower')) {
      setSpeed(prev => Math.max(prev - 0.5, 0.1));
    } else if (command.includes('reset')) {
      handleReset();
    }
  }, []);

  const toggleVoiceRecognition = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const handleFileSelect = (file: File) => {
    if (file && file.name.endsWith('.glb')) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setModelUrl(url);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    const glbFile = files.find(file => file.name.endsWith('.glb'));
    if (glbFile) {
      handleFileSelect(glbFile);
    }
  }, []);

  const handleReset = () => {
    setIsPlaying(false);
    setAnimationType('float');
    setSpeed(1);
    setGhostMode(false);
    setSelectedFile(null);
    setModelUrl('');
    setLastCommand('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Diva Hologram Ghost
          </h1>
          <p className="text-gray-300">3D Model Viewer with Ghost Animations & Voice Controls</p>
        </div>

        {/* Control Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Animation Controls */}
          <div className="bg-gray-800/50 backdrop-blur rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Animation
            </h3>
            
            <div className="space-y-4">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  isPlaying ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'
                }`}
                data-testid="play-pause-button"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isPlaying ? 'Pause' : 'Play'}
              </button>

              <div>
                <label className="block text-sm font-medium mb-2">Animation Type</label>
                <select
                  value={animationType}
                  onChange={(e) => setAnimationType(e.target.value)}
                  className="w-full bg-gray-700 text-white rounded-lg px-3 py-2"
                  data-testid="animation-select"
                >
                  <option value="float">Float</option>
                  <option value="rotate">Rotate</option>
                  <option value="pulse">Pulse</option>
                  <option value="fade">Fade</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Speed: {speed.toFixed(1)}x
                </label>
                <input
                  type="range"
                  min="0.1"
                  max="3"
                  step="0.1"
                  value={speed}
                  onChange={(e) => setSpeed(parseFloat(e.target.value))}
                  className="w-full"
                  data-testid="speed-slider"
                />
              </div>
            </div>
          </div>

          {/* Ghost Mode */}
          <div className="bg-gray-800/50 backdrop-blur rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Ghost className="w-5 h-5" />
              Ghost Mode
            </h3>
            
            <button
              onClick={() => setGhostMode(!ghostMode)}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                ghostMode ? 'bg-purple-600 hover:bg-purple-700' : 'bg-gray-600 hover:bg-gray-700'
              }`}
              data-testid="ghost-mode-button"
            >
              <Ghost className="w-4 h-4" />
              {ghostMode ? 'Ghost Active' : 'Normal Mode'}
            </button>

            <button
              onClick={() => setParticlesEnabled(!particlesEnabled)}
              className={`w-full mt-2 flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                particlesEnabled ? 'bg-cyan-600 hover:bg-cyan-700' : 'bg-gray-600 hover:bg-gray-700'
              }`}
              data-testid="particles-button"
            >
              <Sparkles className="w-4 h-4" />
              {particlesEnabled ? 'Particles On' : 'Particles Off'}
            </button>
          </div>

          {/* File Upload */}
          <div className="bg-gray-800/50 backdrop-blur rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Model Upload
            </h3>
            
            <div
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
              className="border-2 border-dashed border-gray-600 rounded-lg p-4 text-center hover:border-blue-400 transition-colors"
              data-testid="drop-zone"
            >
              <p className="text-sm text-gray-400 mb-2">
                Drop .GLB file here or
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".glb"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileSelect(file);
                }}
                className="hidden"
                data-testid="file-input"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm transition-colors"
                data-testid="file-select-button"
              >
                Select File
              </button>
            </div>
            
            {selectedFile && (
              <p className="text-sm text-green-400 mt-2" data-testid="selected-file">
                Selected: {selectedFile.name}
              </p>
            )}
          </div>

          {/* Voice Control */}
          <div className="bg-gray-800/50 backdrop-blur rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Mic className="w-5 h-5" />
              Voice Control
            </h3>
            
            <button
              onClick={toggleVoiceRecognition}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isListening ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
              }`}
              data-testid="voice-button"
            >
              <Mic className="w-4 h-4" />
              {isListening ? 'Stop Listening' : 'Start Listening'}
            </button>

            <div className="mt-4">
              <p className="text-xs text-gray-400 mb-1">Status:</p>
              <p className="text-sm" data-testid="voice-status">
                {isListening ? 'Listening...' : 'Not listening'}
              </p>
              
              {lastCommand && (
                <div className="mt-2">
                  <p className="text-xs text-gray-400 mb-1">Last Command:</p>
                  <p className="text-sm text-cyan-400" data-testid="last-command">
                    "{lastCommand}"
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reset Button */}
        <div className="text-center mb-8">
          <button
            onClick={handleReset}
            className="bg-gray-600 hover:bg-gray-700 px-6 py-2 rounded-lg transition-colors flex items-center gap-2 mx-auto"
            data-testid="reset-button"
          >
            <RotateCcw className="w-4 h-4" />
            Reset All
          </button>
        </div>

        {/* Hologram Viewports */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((viewport) => (
            <div
              key={viewport}
              className="relative bg-gray-900/50 backdrop-blur rounded-lg overflow-hidden border border-cyan-500/30 h-80"
              data-testid={`viewport-${viewport}`}
            >
              <div className="absolute top-4 left-4 z-10 bg-black/50 px-3 py-1 rounded-full text-sm">
                Viewport {viewport}
              </div>
              
              <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
                <ambientLight intensity={0.5} />
                <pointLight position={[10, 10, 10]} />
                <spotLight
                  position={[0, 10, 0]}
                  angle={0.3}
                  penumbra={1}
                  intensity={1}
                  color={ghostMode ? "#9333ea" : "#64ffda"}
                />
                
                {particlesEnabled && <ParticleSystem />}
                
                <HologramModel
                  modelUrl={modelUrl}
                  animationType={isPlaying ? animationType : 'none'}
                  speed={speed}
                  ghostMode={ghostMode}
                />
                
                <OrbitControls
                  enablePan={false}
                  enableZoom={true}
                  enableRotate={true}
                  maxDistance={10}
                  minDistance={2}
                />
              </Canvas>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}