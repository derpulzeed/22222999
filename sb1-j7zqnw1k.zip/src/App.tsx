import React from 'react';
import DivaHologramGhost from './components/DivaHologramGhost';

function App() {
  return <DivaHologramGhost />;
}

export default App;