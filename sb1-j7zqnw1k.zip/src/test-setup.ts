import '@testing-library/jest-dom';

// Mock Web Speech API
global.SpeechRecognition = class MockSpeechRecognition {
  continuous = false;
  interimResults = false;
  lang = 'en-US';
  onresult = null;
  onerror = null;
  onstart = null;
  onend = null;
  
  start() {
    if (this.onstart) this.onstart();
  }
  
  stop() {
    if (this.onend) this.onend();
  }
  
  abort() {
    if (this.onend) this.onend();
  }
};

global.webkitSpeechRecognition = global.SpeechRecognition;

// Mock URL.createObjectURL
global.URL.createObjectURL = vi.fn(() => 'mocked-object-url');
global.URL.revokeObjectURL = vi.fn();

// Mock HTMLMediaElement methods
Object.defineProperty(HTMLMediaElement.prototype, 'load', {
  writable: true,
  value: vi.fn(),
});

Object.defineProperty(HTMLMediaElement.prototype, 'play', {
  writable: true,
  value: vi.fn().mockResolvedValue(undefined),
});

Object.defineProperty(HTMLMediaElement.prototype, 'pause', {
  writable: true,
  value: vi.fn(),
});